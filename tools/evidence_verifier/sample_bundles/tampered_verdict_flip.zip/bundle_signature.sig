{
  "algorithm": "HMAC-SHA256",
  "record_id": "VER-20261124-video-demo-vid-69893ffe",
  "hashes_sha256": "2e32c176ea318e155527cac52d3800d5b49a1474d578e0f3ba0b91b9b7b38630",
  "evidence_sha256": "faf82bd7bbfef379b89456481c7d53a5b204e42f1add2ae47820146c02215a71",
  "signature": "d7b0bcf4fc580fd377c5e9a1044f9bc9c5ca385ecb82797cf0e98c25ef77cc8c"
}