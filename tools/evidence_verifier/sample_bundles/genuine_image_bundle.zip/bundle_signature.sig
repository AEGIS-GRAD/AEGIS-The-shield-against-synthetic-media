{
  "algorithm": "HMAC-SHA256",
  "record_id": "VER-20261124-image-demo-ima-5763f120",
  "hashes_sha256": "e85c29132f3aba30167d619cee0d50ae89beb2784b68547496a037ffb484456f",
  "evidence_sha256": "7eed2bb9f385015d429ff3a6595335eb5ecdd87583e517bbec3d06fb7598a4e3",
  "signature": "6226d6afe609c92d02755c9781273a46689b8b7ab7aeb93a4165a9954118c1e1"
}