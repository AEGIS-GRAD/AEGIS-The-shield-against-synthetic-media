{
  "algorithm": "HMAC-SHA256",
  "record_id": "VER-20261124-video-demo-vid-69893ffe",
  "hashes_sha256": "b38375949bbc67ac48f8efc12cf54d302477908e567aeec974d26ec52f4c6e31",
  "evidence_sha256": "43e51feb0501ae8774da5c09a2a81f75da211593d6e2bcd22e051267c00d9f19",
  "signature": "61f4134282d51839d3c717c0f9a96b585bffa831712edd978865af6c68f1ce02"
}