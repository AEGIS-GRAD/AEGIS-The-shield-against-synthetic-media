{
  "algorithm": "HMAC-SHA256",
  "record_id": "VER-20261124-multimodal-demo-mul-abfe2512",
  "hashes_sha256": "d0edf1b4f71ce3ab2f3f523d98aec42f218dee304b843c47618f4b9be870b91c",
  "evidence_sha256": "7f2eeadac00ef605fcb41900a548d2e83c6519f44971f45b95629459320ea55d",
  "signature": "82069f1626283f244b91be721bb388ecd2933946cee66761aba07df281b9cb02"
}