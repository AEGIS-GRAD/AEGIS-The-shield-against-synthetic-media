{
  "algorithm": "HMAC-SHA256",
  "record_id": "VER-20261124-text-demo-tex-c33c898b",
  "hashes_sha256": "54368903eadfbc419bf8f31a969b58a0f4dd227a1d03d1f186f5dbfd2c1f6d17",
  "evidence_sha256": "7b98b7b98f0067f1049b83c8b265d826b873bb65ffe5e38d5cde7f174a85e6c7",
  "signature": "4e35dd74c603b183eae2fd9c61b2ec558ba3f79078d013cb94547bca06e563e8"
}