# AEGIS Forensic Verification Report

- **Verification ID:** `VER-20261124-video-demo-vid-69893ffe`
- **Job ID:** `demo-video-001`
- **Timestamp (UTC):** 2026-11-24T20:41:10.500304+00:00
- **Modality:** `video`
- **Input Filename:** `spokesperson_briefing.mp4`
- **Input SHA-256:** `27a6532f4ee8a39542dbd5b3be3ce7178b137120e3e43478692d1e72ec4a6d40`
- **Final Verdict:** **AUTHENTIC**
- **Calibrated Score:** 0.9140
- **Calibration Version:** `aegis-calibrator-v2.0`
- **SIEM Alert Tier:** `P1_CRITICAL`

## Model Versions
- `video-classifier`: `efficientnet-b0-df40-v1`
- `syncnet`: `syncnet-v1.3`
- `rppg`: `chrom-v1.2`

## Detector Outputs
- **video-classifier** (`ok`): score=0.94, confidence=0.94, latency=1380ms
- **syncnet** (`ok`): score=0.88, confidence=0.88, latency=920ms
- **rppg** (`ok`): score=0.19, confidence=0.19, latency=610ms

## Judge Agent Debate Transcript
- **Judge Mode:** `expert_deterministic_judge`
- **Debate Transcript Hash:** `1974d96dec1fd4103842663c0d46666d68619707960d4b88e00ecd2120a94728`
- **Guards Applied:** `G1_CONFLICT_CHECK, G2B_SECONDARY_PROXY_CAP`
- **Forensic Justification:** Precedence Rule 3 applied: facial synthesis & lip-desync override donor rPPG pulse.

### Round 1: Claim Submissions
Collected video evidence claims.

### Round 2: Cross-Examination & Context Injection
Precedence Rule 3 applied: facial synthesis & lip-desync override donor rPPG pulse.

### Round 3: Adjudication & Forensic Ruling
Final verdict=AUTHENTIC.

## Cryptographic Chain of Custody
- **Ledger Index:** 1
- **Previous Record Hash:** `e6849907c894ec831f09d9c796d9403c75ccd68ae8baca983da0e40a49de3aa0`
- **Record Hash:** `6a507f7a03a4c08e4fbbac71aacc546ae234ec8cb8dcc4cb978803d7329a8a07`
- **HMAC-SHA256 Signature:** `c84d201daafba7cac602a378d29f13304d14b9eb78041333dfafcb38b99aafb8`
