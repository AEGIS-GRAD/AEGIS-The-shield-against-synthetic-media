# AEGIS Forensic Verification Report

- **Verification ID:** `VER-20261124-text-demo-tex-c33c898b`
- **Job ID:** `demo-text-004`
- **Timestamp (UTC):** 2026-11-24T20:41:10.608726+00:00
- **Modality:** `text`
- **Input Filename:** `statement_draft.txt`
- **Input SHA-256:** `6f54df63a7ff87e23788cd77bc50609ae2391f4a5fba26756b7f5bbbb900b82a`
- **Final Verdict:** **SYNTHETIC**
- **Calibrated Score:** 0.8650
- **Calibration Version:** `aegis-calibrator-v2.0`
- **SIEM Alert Tier:** `P1_CRITICAL`

## Model Versions
- `detector_text`: `desklib-ai-text-detector-v1.01-lora`

## Detector Outputs
- **detector_text** (`ok`): score=0.87, confidence=0.87, latency=185ms

## Judge Agent Debate Transcript
- **Judge Mode:** `expert_deterministic_judge`
- **Debate Transcript Hash:** `513b0ef81a147e4b647c7a3760da898970352d9766c32710a1c7cd66e11d8c22`
- **Guards Applied:** `G1_CONFLICT_CHECK, G2B_SECONDARY_PROXY_CAP`
- **Forensic Justification:** Desklib semantic classifier corroborated by uniformly low GPT-2 sentence burstiness.

### Round 1: Claim Submissions
Collected text evidence claims.

### Round 2: Cross-Examination & Context Injection
Desklib semantic classifier corroborated by uniformly low GPT-2 sentence burstiness.

### Round 3: Adjudication & Forensic Ruling
Final verdict=SYNTHETIC.

## Cryptographic Chain of Custody
- **Ledger Index:** 4
- **Previous Record Hash:** `c5ce99cb07e3600f66d7b722368e659d8fc35837129e26b0f0ac2840adcd7699`
- **Record Hash:** `548c6474c19a8ef47c6055ffec9fb9a41da2aa7ab1a5edee3ce6b1204d2ec7e3`
- **HMAC-SHA256 Signature:** `65c8e77d393fc072ed34df99cd17af5e86b01347618e27ebd938759a08279b5c`
