# AEGIS Forensic Verification Report

- **Verification ID:** `VER-20261124-multimodal-demo-mul-abfe2512`
- **Job ID:** `demo-multi-005`
- **Timestamp (UTC):** 2026-11-24T20:41:10.642457+00:00
- **Modality:** `multimodal`
- **Input Filename:** `broadcast_interview.mp4`
- **Input SHA-256:** `c916febb6ff572b36cfb03dddc743d5dca9e92d46925dbcb77e193d1bc1045e3`
- **Final Verdict:** **SYNTHETIC**
- **Calibrated Score:** 0.9280
- **Calibration Version:** `aegis-calibrator-v2.0`
- **SIEM Alert Tier:** `P1_CRITICAL`

## Model Versions
- `video-classifier`: `efficientnet-b0-df40-v1`
- `aasist`: `aasist-sincnet-v1.3`
- `syncnet`: `syncnet-v1.3`
- `rppg`: `chrom-v1.2`

## Detector Outputs
- **video-classifier** (`ok`): score=0.93, confidence=0.93, latency=1410ms
- **aasist** (`ok`): score=0.91, confidence=0.91, latency=230ms
- **syncnet** (`ok`): score=0.86, confidence=0.86, latency=910ms
- **rppg** (`ok`): score=0.76, confidence=0.76, latency=640ms

## Judge Agent Debate Transcript
- **Judge Mode:** `expert_deterministic_judge`
- **Debate Transcript Hash:** `07c79a25e9e5a2d0415e2da535bb561f016a692573426acbbf8d4b5fa20e3706`
- **Guards Applied:** `G1_CONFLICT_CHECK, G2B_SECONDARY_PROXY_CAP`
- **Forensic Justification:** Cross-modal consensus across visual, acoustic, lip-sync, and physiological channels.

### Round 1: Claim Submissions
Collected multimodal evidence claims.

### Round 2: Cross-Examination & Context Injection
Cross-modal consensus across visual, acoustic, lip-sync, and physiological channels.

### Round 3: Adjudication & Forensic Ruling
Final verdict=SYNTHETIC.

## Cryptographic Chain of Custody
- **Ledger Index:** 5
- **Previous Record Hash:** `548c6474c19a8ef47c6055ffec9fb9a41da2aa7ab1a5edee3ce6b1204d2ec7e3`
- **Record Hash:** `92830e7b814a53904f7caca6c3b8a0a18512d58d77550dd09676da9bd591b00e`
- **HMAC-SHA256 Signature:** `c28dc641cbf1997b9b0c938efe68faadfcf794aa31352b2d36c474e6fc2c95d1`
