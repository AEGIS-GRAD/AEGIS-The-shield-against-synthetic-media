{
  "algorithm": "HMAC-SHA256",
  "record_id": "VER-20261124-audio-demo-aud-be729915",
  "hashes_sha256": "455483fbc7c49fab907494d33c1edf7fcdec26c2becabda921081c3ccc40ae43",
  "evidence_sha256": "0239cc6d5542396aea00f76941773ce6e17aafba7d4fb67552b85db507bbb77f",
  "signature": "065286bb63545d44e1b776810a2d0fe05cc5093a3e249711439f59dd4524a180"
}