# AEGIS Forensic Verification Report

- **Verification ID:** `VER-20261124-audio-demo-aud-be729915`
- **Job ID:** `demo-audio-002`
- **Timestamp (UTC):** 2026-11-24T20:41:10.538303+00:00
- **Modality:** `audio`
- **Input Filename:** `executive_voicemail.wav`
- **Input SHA-256:** `a6eaa461dfb1f99a81205be54b39da73dab99b8e72299674d2591e9b2f4b1bac`
- **Final Verdict:** **SYNTHETIC**
- **Calibrated Score:** 0.8820
- **Calibration Version:** `aegis-calibrator-v2.0`
- **SIEM Alert Tier:** `P1_CRITICAL`

## Model Versions
- `aasist`: `aasist-sincnet-v1.3`

## Detector Outputs
- **aasist** (`ok`): score=0.89, confidence=0.89, latency=215ms

## Judge Agent Debate Transcript
- **Judge Mode:** `expert_deterministic_judge`
- **Debate Transcript Hash:** `dde8fbccc1ab1a5c14330bdd999ebdc9587522e77804eea79841d0875806aa49`
- **Guards Applied:** `G1_CONFLICT_CHECK, G2B_SECONDARY_PROXY_CAP`
- **Forensic Justification:** AASIST spectro-temporal graph attention detected neural voice cloning artifacts.

### Round 1: Claim Submissions
Collected audio evidence claims.

### Round 2: Cross-Examination & Context Injection
AASIST spectro-temporal graph attention detected neural voice cloning artifacts.

### Round 3: Adjudication & Forensic Ruling
Final verdict=SYNTHETIC.

## Cryptographic Chain of Custody
- **Ledger Index:** 2
- **Previous Record Hash:** `6a507f7a03a4c08e4fbbac71aacc546ae234ec8cb8dcc4cb978803d7329a8a07`
- **Record Hash:** `378266f21b27e4004ac9bca7a88fb16b764855ad84841b50244a6f9d8b61948e`
- **HMAC-SHA256 Signature:** `6b2835905420a35e46b1cb86396fadb6280309d0072f726612a42c58b9e50aed`
