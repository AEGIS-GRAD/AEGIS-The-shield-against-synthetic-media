{
  "algorithm": "HMAC-SHA256",
  "record_id": "INC-20261124-cam-lobby-mtls-01-SEQ421-125de913",
  "hashes_sha256": "6e8e9703b96fa4933ec765fa72956b9ad49e293d00a9c3a9a662eb491191882e",
  "evidence_sha256": "2176507ee4d30e6eee323aaeddc7d990fb04fdb6fb98af53eb9f77e11aca0ca5",
  "signature": "caddab0cdc1fa0eafd399e1efc287d1e767cbb5e90cefba985e7e0c7bf89514b"
}