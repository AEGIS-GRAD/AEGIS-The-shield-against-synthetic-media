# AEGIS Live Surveillance Incident Report

- **Incident ID:** `INC-20261124-cam-lobby-mtls-01-SEQ421-125de913`
- **Timestamp (UTC):** 2026-11-24T20:41:10.684060+00:00
- **Camera ID:** `cam-lobby-mtls-01`
- **Threat Type:** `HASH_CHAIN_BREAK`
- **Severity:** `CRITICAL`
- **Sequence Number:** 421
- **Primary Frame SHA-256:** `0ab3e2fde8fd627621cbdeda0efa635d52c26d05e70381acbf162220a0a73050`
- **Reasoning Narrative:** Frame hash-chain continuity broken between seq 420 and 421 over mTLS ingestion.

## Cryptographic Chain of Custody
- **Ledger Index:** 6
- **Previous Record Hash:** `92830e7b814a53904f7caca6c3b8a0a18512d58d77550dd09676da9bd591b00e`
- **Record Hash:** `a6a3d5d0133243db68ca440995a440c481ef5af9d690223c335abb86ace0aba9`
- **HMAC-SHA256 Signature:** `5b23e1640ac4393f3729b5bc846e218e80089c6fd648120a8e06bd1c872a4e0b`
