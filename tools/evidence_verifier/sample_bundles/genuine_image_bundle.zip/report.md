# AEGIS Forensic Verification Report

- **Verification ID:** `VER-20261124-image-demo-ima-5763f120`
- **Job ID:** `demo-image-003`
- **Timestamp (UTC):** 2026-11-24T20:41:10.572310+00:00
- **Modality:** `image`
- **Input Filename:** `press_photo.png`
- **Input SHA-256:** `2ad084c2cb4896abc916806de8bb039b353cda5f0c1ac76c729f41e2808470a9`
- **Final Verdict:** **AUTHENTIC**
- **Calibrated Score:** 0.1150
- **Calibration Version:** `aegis-calibrator-v2.0`
- **SIEM Alert Tier:** `P4_INFORMATIONAL`

## Model Versions
- `detector_image`: `commfor-model-384-fp16`

## Detector Outputs
- **detector_image** (`ok`): score=0.12, confidence=0.12, latency=110ms

## Judge Agent Debate Transcript
- **Judge Mode:** `expert_deterministic_judge`
- **Debate Transcript Hash:** `c3f1ab7e80e74e29dfd9e514a8d35bd7087dee82c5dc9dfe1292663ef5d0f95a`
- **Guards Applied:** `G1_CONFLICT_CHECK, G2B_SECONDARY_PROXY_CAP`
- **Forensic Justification:** No diffusion grid or GAN upsampling anomalies detected; consistent EXIF profile.

### Round 1: Claim Submissions
Collected image evidence claims.

### Round 2: Cross-Examination & Context Injection
No diffusion grid or GAN upsampling anomalies detected; consistent EXIF profile.

### Round 3: Adjudication & Forensic Ruling
Final verdict=AUTHENTIC.

## Cryptographic Chain of Custody
- **Ledger Index:** 3
- **Previous Record Hash:** `378266f21b27e4004ac9bca7a88fb16b764855ad84841b50244a6f9d8b61948e`
- **Record Hash:** `c5ce99cb07e3600f66d7b722368e659d8fc35837129e26b0f0ac2840adcd7699`
- **HMAC-SHA256 Signature:** `2889b3018fb3ecaf7f9e7a217a499cbf2435f215f5d17770b0bdc4d308e0b9ef`
